# JavaScript Practice Problems

Solutions to the 9 questions in `Practice_Problem.pdf`.

## Requirements
- Node.js (optional, if you want to run the file locally)

## Run
```bash
node practice.js
```

## Topics covered
1. `for` loop
2. Array sum using `reduce`
3. Largest number in an array
4. Even or odd
5. Reverse a string
6. Merge arrays using the spread operator
7. Filter even numbers
8. Template literals
9. Arrow function
